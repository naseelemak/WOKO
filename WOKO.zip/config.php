<?php

session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "woko";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

?>